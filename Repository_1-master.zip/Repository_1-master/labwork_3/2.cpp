#include <iostream>
#include <string>
using namespace std;
int main()
{
	string s="deb http://mirror.mephi.ru/debian/stretch main contrib non-free\ndeb-src http://mirror.mephi.ru/debian/ stretch main contrib non-free\ndeb http://security.debian.org/ stretch/updates main contrib non-free\ndeb-src http://security.debian.org/ stretch/updates main contrib non-free\ndeb http://mirror.mephi.ru/debian/ stretch-updates main contrib non-free\ndeb-src http://mirror.mephi.ru/debian/ stretch-updates main contrib non-free\ndeb http://mirror.mephi.ru/debian stretch-backports main contrib non-free\ndeb-src http://mirror.mephi.ru/debian stretch-backports main contrib non-free";
	while (s.find("mephi")!=string::npos) {
		s.replace(s.find("mephi"), 5, "yandex");
	}
	cout<<s<<endl;
	return 0;
}